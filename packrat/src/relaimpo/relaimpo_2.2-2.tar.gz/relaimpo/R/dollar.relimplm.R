"$.relimplm" <-
function(x,name){slot(x,name)}

