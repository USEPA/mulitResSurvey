boot.relimp <- function(object, ...)
   UseMethod("boot.relimp")

