alltype <- function(){c("lmg","last", "first", "betasq", "pratt", "genizi", "car")}

