rsquared = function(modelList, aicc = FALSE) {
  
  sem.model.fits(modelList, aicc)
  
}