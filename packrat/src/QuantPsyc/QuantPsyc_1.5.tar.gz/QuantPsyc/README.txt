Changes to v. 1.2 
	changed affiliation from @umsl.edu to @statefarm.com

Changes to v. 1.3 
	There was a grammar error in help files with examples involving boot() with mediation
	
Changes to v. 1.4
	Corrected numerous help file errors (syntax issues)
	Renamed 2 functions to eliminate a conflict with classes. 
	mean.center is now meanCenter
	plot.normX (plot.normXm) is now plotNormX (plotNormXm)
	Changes to plotNormXm, now incorporates a for loop
	added 2 new functions: ClassLog and NormalizeX
	
Changes to v. 1.5
	functions using sd() needed to be revised to sapply(MAT, sd)
	added minor to tweaks to make suitable for R 2.15 upgrade (e.g., 
	changed library(PACKAGE) to require(PACKAGE) in examples)
	
