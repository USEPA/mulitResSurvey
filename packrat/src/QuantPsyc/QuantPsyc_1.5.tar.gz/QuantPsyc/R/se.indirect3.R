"se.indirect3" <-
function (a,sa,b,sb,c,sc) 
{ 
sqrt(a^2*b^2*sc^2 + a^2*c^2*sb^2 + b^2*c^2*sa^2)

}

