"aroian.se.indirect2" <-
function (a,sa,b,sb) 
{ 
sqrt(a^2*sb^2 + b^2*sa^2 + sa^2*sb^2 )

}

